package com.example.contacliquesolano;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    public Button getBotaoIncrementa() {
        return botaoIncrementa;
    }

    public void setBotaoIncrementa(Button botaoIncrementa) {
        this.botaoIncrementa = botaoIncrementa;
    }

    public TextView getDisplayValor() {
        return displayValor;
    }

    public void setDisplayValor(TextView displayValor) {
        this.displayValor = displayValor;
    }

    public int getAcumulador() {
        return acumulador;
    }

    public void setAcumulador(int acumulador) {
        this.acumulador = acumulador;
    }

    private Button botaoIncrementa;
    private TextView displayValor;
    private int acumulador;

    public EditText getEdit() {
        return edit;
    }

    public void setEdit(EditText edit) {
        this.edit = edit;
    }

    private EditText edit;

    public void incrementaValor(View v){
        setAcumulador(getAcumulador() + 1000);
        getDisplayValor().setText(String.valueOf(getAcumulador()));
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        setAcumulador(10000);
        setBotaoIncrementa(findViewById(R.id.botaoIncrementa));
        setDisplayValor(findViewById(R.id.displayValorAcumulado));
        setEdit(findViewById(R.id.edit));




    }


}