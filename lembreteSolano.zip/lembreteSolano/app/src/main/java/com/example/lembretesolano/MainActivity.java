package com.example.lembretesolano;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    Button botaoEntrar;
    TextView caixaNome;


    public Button getBotaoEntrar() {
        return botaoEntrar;
    }

    public void setBotaoEntrar(Button botaoEntrar) {
        this.botaoEntrar = botaoEntrar;
    }

    public TextView getCaixaNome() {
        return caixaNome;
    }

    public void setCaixaNome(TextView caixaNome) {
        this.caixaNome = caixaNome;
    }

    public void entrarApp(View view){
        Intent nextActivity = new Intent(MainActivity.this, telaLembrete.class);
        nextActivity.putExtra("nomeUsuario", getCaixaNome().getText().toString());
        startActivity(nextActivity);

    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        setBotaoEntrar(findViewById(R.id.botaoEntrar));
        setCaixaNome(findViewById(R.id.caixaNome));

    }
}