package com.example.lembretesolano;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class telaLembrete extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tela_lembrete);
    }
}